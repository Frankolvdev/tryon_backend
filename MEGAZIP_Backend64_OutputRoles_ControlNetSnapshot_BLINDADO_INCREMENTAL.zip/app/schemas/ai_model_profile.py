from datetime import datetime
from uuid import UUID
from typing import Any, Literal
from pydantic import BaseModel, Field

SexName = Literal["woman", "man"]

class BodyVariantResponse(BaseModel):
    id: int
    display_name: str
    sex: SexName
    hips_size: float
    fat_thin: float
    breasts_size: float
    skin_tone: float
    hair_length: float
    fat_band: str | None = None
    hips_band: str | None = None
    breast_band: str | None = None
    image_url: str
    sort_order: float

class BodyVariantCatalogResponse(BaseModel):
    items: list[BodyVariantResponse]
    total: int

class BubbleButtVariantResponse(BaseModel):
    id: int
    variant_index: int
    display_name: str
    bubble_butt: float
    image_url: str

class BubbleButtVariantCatalogResponse(BaseModel):
    items: list[BubbleButtVariantResponse]
    total: int

class AiModelProfileCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    sex: SexName = "woman"

class AiModelProfileBodyUpdate(BaseModel):
    body_proportion_preset_id: int
    bubble_butt_preset_id: int

class AiModelProfileDraftUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    draft: dict[str, Any] = Field(default_factory=dict)

class AiModelProfileFinalizeRequest(BaseModel):
    execution_id: UUID
    storage_file_id: int = Field(gt=0)
    primary_output_id: int | None = Field(default=None, gt=0)
    identity_face_storage_file_id: int | None = Field(default=None, gt=0)
    identity_face_output_id: int | None = Field(default=None, gt=0)

class AiModelProfileResponse(BaseModel):
    id: int
    name: str
    sex: SexName
    body_proportion_preset_id: int | None
    bubble_butt_preset_id: int | None = None
    bubble_butt_variant_index: int | None = None
    body_image_url: str | None = None
    generated_image_url: str | None = None
    selected_generation_file_id: int | None = None
    stage: str
    draft_json: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime
