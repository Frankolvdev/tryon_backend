import json
import logging
import re
import time
from pathlib import Path
from typing import Any
from urllib.parse import urlencode
from uuid import uuid4

import httpx

from app.core.config import settings
from copy import deepcopy

from app.services.docker_local_runtime_manager_service import docker_local_runtime_manager_service
from app.services.comfyui_prompt_preprocessor_service import (
    comfyui_prompt_preprocessor_service,
)

logger = logging.getLogger(__name__)


class ComfyUILocalAdapterService:
    def __init__(self, base_url: str | None = None) -> None:
        self._configured_base_url = str(base_url).rstrip("/") if base_url else None
        self._resolved_base_url: str | None = None

    def _base_url(self) -> str:
        if self._resolved_base_url:
            return self._resolved_base_url
        if self._configured_base_url:
            if docker_local_runtime_manager_service.is_managed_target(self._configured_base_url):
                self._resolved_base_url = docker_local_runtime_manager_service.ensure_endpoint(
                    self._configured_base_url
                ).rstrip("/")
                return self._resolved_base_url
            return self._configured_base_url
        configured_url = getattr(settings, "COMFYUI_BASE_URL", None)
        if configured_url:
            return str(configured_url).rstrip("/")
        return "http://127.0.0.1:8188"

    def _timeout_seconds(self) -> float:
        return float(getattr(settings, "COMFYUI_HTTP_TIMEOUT_SECONDS", 30))

    def _poll_interval_seconds(self) -> float:
        configured = float(
            getattr(settings, "COMFYUI_POLL_INTERVAL_SECONDS", 1.0)
        )
        return max(configured, 0.75)

    def _progress_event_interval_seconds(self) -> float:
        configured = float(
            getattr(settings, "COMFYUI_PROGRESS_EVENT_INTERVAL_SECONDS", 5.0)
        )
        return max(configured, 2.0)

    def _output_root(self) -> Path:
        local_storage_dir = str(
            getattr(settings, "LOCAL_STORAGE_DIR", "storage")
        )
        output_dir = Path(local_storage_dir) / "comfyui-results"
        output_dir.mkdir(parents=True, exist_ok=True)
        return output_dir

    def _safe_local_filename(self, filename: str) -> str:
        original_name = Path(str(filename)).name
        sanitized = re.sub(r'[<>:"/\\|?*\x00-\x1F]', "_", original_name)
        sanitized = sanitized.rstrip(" .")

        if not sanitized:
            sanitized = "comfyui-output"

        reserved_names = {
            "CON", "PRN", "AUX", "NUL",
            *(f"COM{index}" for index in range(1, 10)),
            *(f"LPT{index}" for index in range(1, 10)),
        }
        stem = Path(sanitized).stem.upper()
        if stem in reserved_names:
            sanitized = f"_{sanitized}"

        return sanitized

    def _client(self, *, timeout: float | None = None) -> httpx.Client:
        limits = httpx.Limits(
            max_connections=10,
            max_keepalive_connections=5,
            keepalive_expiry=30.0,
        )
        return httpx.Client(
            timeout=timeout or self._timeout_seconds(),
            limits=limits,
            headers={"Connection": "keep-alive"},
        )

    def health(self) -> dict[str, Any]:
        try:
            with self._client() as client:
                response = client.get(f"{self._base_url()}/system_stats")
                response.raise_for_status()
                return {
                    "available": True,
                    "base_url": self._base_url(),
                    "system_stats": response.json(),
                }
        except Exception as error:
            return {
                "available": False,
                "base_url": self._base_url(),
                "error": str(error),
            }

    def upload_input(
        self,
        *,
        content: bytes,
        filename: str,
        content_type: str,
        subfolder: str = "",
    ) -> dict[str, Any]:
        files = {"image": (filename, content, content_type)}
        data = {"type": "input", "overwrite": "false"}
        if subfolder:
            data["subfolder"] = subfolder

        with self._client() as client:
            response = client.post(
                f"{self._base_url()}/upload/image",
                files=files,
                data=data,
            )
            response.raise_for_status()
            result = response.json()

        if not isinstance(result, dict) or not result.get("name"):
            raise RuntimeError(
                "ComfyUI did not accept the generation input file."
            )
        return result

    def queue_prompt(
        self,
        *,
        workflow: dict[str, Any],
        client_id: str | None = None,
        extra_data: dict[str, Any] | None = None,
        preserve_workflow_paths: bool = False,
    ) -> dict[str, Any]:
        resolved_client_id = client_id or uuid4().hex
        if preserve_workflow_paths:
            # Opt-in used by isolated tools that must submit the uploaded
            # ComfyUI API workflow exactly as stored. Existing callers keep
            # the historical normalization behavior by default.
            normalized_workflow = deepcopy(workflow)
        else:
            normalized_workflow = comfyui_prompt_preprocessor_service.preprocess(
                workflow
            )
            comfyui_prompt_preprocessor_service.assert_no_windows_model_paths(
                normalized_workflow
            )
        body: dict[str, Any] = {
            "prompt": normalized_workflow,
            "client_id": resolved_client_id,
        }
        if extra_data:
            body["extra_data"] = extra_data

        with self._client() as client:
            response = client.post(
                f"{self._base_url()}/prompt",
                json=body,
            )
            response.raise_for_status()
            data = response.json()

        prompt_id = data.get("prompt_id")
        if not prompt_id:
            raise RuntimeError("ComfyUI did not return a prompt_id.")

        node_errors = data.get("node_errors", {})
        if node_errors:
            raise RuntimeError(
                "ComfyUI rejected the workflow: "
                + json.dumps(
                    node_errors,
                    ensure_ascii=False,
                    default=str,
                )
            )

        return {
            "prompt_id": str(prompt_id),
            "client_id": resolved_client_id,
            "number": data.get("number"),
            "node_errors": node_errors,
        }

    def _get_history_with_client(
        self,
        client: httpx.Client,
        *,
        prompt_id: str,
    ) -> dict[str, Any] | None:
        response = client.get(
            f"{self._base_url()}/history/{prompt_id}"
        )
        response.raise_for_status()
        history = response.json()
        item = history.get(prompt_id)
        if isinstance(item, dict):
            return item
        return None

    def get_history(self, *, prompt_id: str) -> dict[str, Any] | None:
        with self._client() as client:
            return self._get_history_with_client(
                client,
                prompt_id=prompt_id,
            )

    def get_queue(self) -> dict[str, Any]:
        with self._client() as client:
            response = client.get(f"{self._base_url()}/queue")
            response.raise_for_status()
            return response.json()

    def interrupt(self) -> bool:
        try:
            with self._client() as client:
                response = client.post(
                    f"{self._base_url()}/interrupt",
                    json={},
                )
                response.raise_for_status()
                return True
        except Exception as error:
            logger.warning("Could not interrupt ComfyUI: %s", error)
            return False

    def delete_queued_prompt(self, *, prompt_id: str) -> bool:
        try:
            with self._client() as client:
                response = client.post(
                    f"{self._base_url()}/queue",
                    json={"delete": [prompt_id]},
                )
                response.raise_for_status()
                return True
        except Exception as error:
            logger.warning(
                "Could not delete queued ComfyUI prompt %s: %s",
                prompt_id,
                error,
            )
            return False

    def cancel_prompt(self, *, prompt_id: str) -> dict[str, Any]:
        deleted = self.delete_queued_prompt(prompt_id=prompt_id)
        interrupted = self.interrupt()
        return {
            "prompt_id": prompt_id,
            "deleted_from_queue": deleted,
            "interrupt_sent": interrupted,
        }

    def cancel_prompt_and_wait(self, *, prompt_id: str, timeout_seconds: int = 30) -> dict[str, Any]:
        initial_queue = self.get_queue()
        pending = initial_queue.get("queue_pending") or []
        running = initial_queue.get("queue_running") or []
        queued_before = any(str(row[1] if isinstance(row, list) and len(row) > 1 else "") == prompt_id for row in pending)
        running_before = any(str(row[1] if isinstance(row, list) and len(row) > 1 else "") == prompt_id for row in running)
        deleted = self.delete_queued_prompt(prompt_id=prompt_id) if queued_before else False
        interrupted = self.interrupt() if running_before or not queued_before else False
        deadline = time.monotonic() + max(5, timeout_seconds)
        while time.monotonic() < deadline:
            queue = self.get_queue()
            pending = queue.get("queue_pending") or []
            running = queue.get("queue_running") or []
            still_pending = any(str(row[1] if isinstance(row, list) and len(row) > 1 else "") == prompt_id for row in pending)
            still_running = any(str(row[1] if isinstance(row, list) and len(row) > 1 else "") == prompt_id for row in running)
            history = self.get_history(prompt_id=prompt_id)
            if not still_pending and not still_running:
                return {
                    "prompt_id": prompt_id,
                    "confirmed": True,
                    "deleted_from_queue": deleted,
                    "interrupt_sent": interrupted,
                    "history": history,
                }
            time.sleep(0.5)
        return {
            "prompt_id": prompt_id,
            "confirmed": False,
            "deleted_from_queue": deleted,
            "interrupt_sent": interrupted,
        }

    def _is_history_complete(
        self,
        history_item: dict[str, Any],
    ) -> bool:
        status = history_item.get("status", {})
        if isinstance(status, dict):
            completed = status.get("completed")
            if completed is True:
                return True
            status_str = status.get("status_str")
            if status_str in {"success", "error"}:
                return True

        outputs = history_item.get("outputs")
        return isinstance(outputs, dict) and bool(outputs)

    def _history_has_error(
        self,
        history_item: dict[str, Any],
    ) -> tuple[bool, str | None]:
        status = history_item.get("status", {})
        if not isinstance(status, dict):
            return False, None

        status_str = status.get("status_str")
        if status_str == "error":
            messages = status.get("messages", [])
            return (
                True,
                json.dumps(
                    messages,
                    ensure_ascii=False,
                    default=str,
                ),
            )

        messages = status.get("messages", [])
        for message in messages:
            if (
                isinstance(message, list)
                and message
                and message[0]
                in {"execution_error", "execution_interrupted"}
            ):
                return (
                    True,
                    json.dumps(
                        message,
                        ensure_ascii=False,
                        default=str,
                    ),
                )
        return False, None

    def wait_for_completion(
        self,
        *,
        prompt_id: str,
        client_id: str,
        timeout_seconds: int,
        progress_callback=None,
    ) -> dict[str, Any]:
        del client_id  # Completion is resolved reliably through /history.

        started_at = time.monotonic()
        poll_interval = self._poll_interval_seconds()
        event_interval = self._progress_event_interval_seconds()
        last_event_at = 0.0
        transient_failures = 0
        last_history: dict[str, Any] | None = None

        with self._client() as client:
            while True:
                now = time.monotonic()
                elapsed = now - started_at
                if elapsed >= timeout_seconds:
                    raise TimeoutError(
                        "ComfyUI prompt exceeded the configured timeout of "
                        f"{timeout_seconds} seconds."
                    )

                try:
                    history_item = self._get_history_with_client(
                        client,
                        prompt_id=prompt_id,
                    )
                    transient_failures = 0
                except (
                    httpx.TransportError,
                    OSError,
                    ConnectionError,
                ) as error:
                    transient_failures += 1
                    logger.warning(
                        "Transient ComfyUI history error for prompt %s "
                        "(attempt %s; retrying until configured timeout): %s",
                        prompt_id,
                        transient_failures,
                        error,
                    )
                    time.sleep(min(poll_interval * transient_failures, 3.0))
                    continue

                if history_item:
                    last_history = history_item
                    has_error, error_message = self._history_has_error(
                        history_item
                    )
                    if has_error:
                        raise RuntimeError(
                            error_message or "ComfyUI execution failed."
                        )
                    if self._is_history_complete(history_item):
                        return history_item

                if progress_callback and (
                    last_event_at == 0.0 or now - last_event_at >= event_interval
                ):
                    last_event_at = now
                    progress_callback(
                        0.0,
                        "Waiting for ComfyUI.",
                        {"elapsed_seconds": round(elapsed, 2)},
                    )

                time.sleep(poll_interval)

        if last_history:
            return last_history
        raise RuntimeError(
            "ComfyUI completed the prompt, but no history was returned."
        )

    def _iter_output_files(self, history_item: dict[str, Any]):
        outputs = history_item.get("outputs", {})
        if not isinstance(outputs, dict):
            return

        supported_groups = ("images", "gifs", "videos", "audio")
        for node_id, node_output in outputs.items():
            if not isinstance(node_output, dict):
                continue
            for group_name in supported_groups:
                files = node_output.get(group_name, [])
                if not isinstance(files, list):
                    continue
                for file_data in files:
                    if not isinstance(file_data, dict):
                        continue
                    filename = file_data.get("filename")
                    if not filename:
                        continue
                    yield {
                        "node_id": str(node_id),
                        "group": group_name,
                        "filename": filename,
                        "subfolder": file_data.get("subfolder", "") or "",
                        "type": file_data.get("type", "output") or "output",
                    }

    def download_output(
        self,
        *,
        file_data: dict[str, Any],
        job_public_id: str,
        prefer_api_view: bool = False,
    ) -> dict[str, Any]:
        query = urlencode(
            {
                "filename": file_data["filename"],
                "subfolder": file_data.get("subfolder", ""),
                "type": file_data.get("type", "output"),
            }
        )

        with self._client(
            timeout=max(self._timeout_seconds(), 120)
        ) as client:
            endpoints = ("/api/view", "/view") if prefer_api_view else ("/view",)
            response = None
            last_404 = None
            for endpoint in endpoints:
                candidate = client.get(f"{self._base_url()}{endpoint}?{query}")
                if candidate.status_code == 404:
                    last_404 = candidate
                    continue
                candidate.raise_for_status()
                response = candidate
                break
            if response is None:
                if last_404 is not None:
                    last_404.raise_for_status()
                raise RuntimeError("ComfyUI output image could not be downloaded.")
            content = response.content
            content_type = response.headers.get("content-type")

        job_directory = self._output_root() / job_public_id
        job_directory.mkdir(parents=True, exist_ok=True)
        safe_name = self._safe_local_filename(
            str(file_data["filename"])
        )
        safe_node_id = self._safe_local_filename(
            str(file_data.get("node_id") or "node")
        )
        final_filename = self._safe_local_filename(
            f"{safe_node_id}-{uuid4().hex[:8]}-{safe_name}"
        )
        destination = job_directory / final_filename
        destination.write_bytes(content)

        local_storage_root = Path(
            str(getattr(settings, "LOCAL_STORAGE_DIR", "storage"))
        )
        try:
            relative_path = destination.relative_to(
                local_storage_root
            ).as_posix()
        except ValueError:
            relative_path = destination.as_posix()

        return {
            **file_data,
            "local_path": str(destination),
            "storage_key": relative_path,
            "public_url": "/local-files/" + relative_path,
            "size_bytes": len(content),
            "content_type": content_type,
        }

    def collect_outputs(
        self,
        *,
        history_item: dict[str, Any],
        job_public_id: str,
        download_outputs: bool = True,
        prefer_api_view: bool = False,
        allowed_node_ids: set[str] | None = None,
    ) -> list[dict[str, Any]]:
        collected: list[dict[str, Any]] = []
        for file_data in self._iter_output_files(history_item):
            if allowed_node_ids is not None and str(file_data.get("node_id")) not in allowed_node_ids:
                continue
            if download_outputs:
                collected.append(
                    self.download_output(
                        file_data=file_data,
                        job_public_id=job_public_id,
                        prefer_api_view=prefer_api_view,
                    )
                )
            else:
                collected.append(file_data)
        return collected

    def execute_queued_prompt(
        self,
        *,
        prompt_id: str,
        client_id: str,
        job_public_id: str,
        timeout_seconds: int,
        download_outputs: bool = True,
        progress_callback=None,
        prefer_api_view: bool = False,
        allowed_node_ids: set[str] | None = None,
    ) -> dict[str, Any]:
        history_item = self.wait_for_completion(
            prompt_id=prompt_id,
            client_id=client_id,
            timeout_seconds=timeout_seconds,
            progress_callback=progress_callback,
        )
        outputs = self.collect_outputs(
            history_item=history_item,
            job_public_id=job_public_id,
            download_outputs=download_outputs,
            prefer_api_view=prefer_api_view,
            allowed_node_ids=allowed_node_ids,
        )
        return {
            "success": True,
            "provider": "comfyui_local",
            "prompt_id": prompt_id,
            "client_id": client_id,
            "outputs": outputs,
            "output_count": len(outputs),
            "history": history_item,
        }


comfyui_local_adapter_service = ComfyUILocalAdapterService()
