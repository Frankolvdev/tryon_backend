import json
import os
import shutil
import subprocess
import logging
import re

from app.services.runpod_control_plane_service import runpod_control_plane_service

logger = logging.getLogger(__name__)

from sqlalchemy.orm import Session

from app.models.system_setting import SystemSetting
from app.schemas.infrastructure_provider import ModalProviderConfig, RunPodProviderConfig, BeamProviderConfig


class InfrastructureProviderService:
    KEY = "infrastructure_provider_modal"
    RUNPOD_KEY = "infrastructure_provider_runpod"
    BEAM_KEY = "infrastructure_provider_beam"

    @classmethod
    def _get_row(cls, db: Session) -> SystemSetting | None:
        return db.query(SystemSetting).filter(SystemSetting.key == cls.KEY).first()

    @classmethod
    def get_modal(cls, db: Session) -> ModalProviderConfig:
        row = cls._get_row(db)
        if not row or not row.value_json:
            return ModalProviderConfig()
        try:
            return ModalProviderConfig.model_validate(json.loads(row.value_json))
        except Exception:
            return ModalProviderConfig()

    @classmethod
    def save_modal(cls, db: Session, payload: ModalProviderConfig) -> ModalProviderConfig:
        current = cls.get_modal(db)
        data = payload.model_dump()
        if not data.get("token_secret"):
            data["token_secret"] = current.token_secret
        row = cls._get_row(db)
        if row is None:
            row = SystemSetting(
                category="integrations",
                key=cls.KEY,
                label="Modal infrastructure provider",
                description="Modal provider configuration used by Runtime Builder and file tools.",
                value_type="json",
                is_public=False,
                is_editable=True,
                is_sensitive=True,
            )
        row.value_json = json.dumps(data, ensure_ascii=False)
        db.add(row)
        db.commit()
        db.refresh(row)
        return ModalProviderConfig.model_validate(data)

    @classmethod
    def _get_named_row(cls, db: Session, key: str) -> SystemSetting | None:
        return db.query(SystemSetting).filter(SystemSetting.key == key).first()

    @classmethod
    def _get_config(cls, db: Session, key: str, schema):
        row = cls._get_named_row(db, key)
        if not row or not row.value_json: return schema()
        try: return schema.model_validate(json.loads(row.value_json))
        except Exception: return schema()

    @classmethod
    def _save_config(cls, db: Session, key: str, label: str, payload, secret_field: str | tuple[str, ...]):
        current = cls._get_config(db, key, type(payload))
        data = payload.model_dump()
        secret_fields = (secret_field,) if isinstance(secret_field, str) else secret_field
        for field in secret_fields:
            if not data.get(field):
                data[field] = getattr(current, field)
        row = cls._get_named_row(db, key) or SystemSetting(category="integrations", key=key, label=label, description=label, value_type="json", is_public=False, is_editable=True, is_sensitive=True)
        row.value_json = json.dumps(data, ensure_ascii=False); db.add(row); db.commit(); db.refresh(row)
        return type(payload).model_validate(data)

    @classmethod
    def get_runpod(cls, db: Session): return cls._get_config(db, cls.RUNPOD_KEY, RunPodProviderConfig)
    @classmethod
    def save_runpod(cls, db: Session, payload): return cls._save_config(db, cls.RUNPOD_KEY, "RunPod Serverless infrastructure provider", payload, ("api_key", "s3_secret_key", "ghcr_token"))
    @classmethod
    def get_beam(cls, db: Session): return cls._get_config(db, cls.BEAM_KEY, BeamProviderConfig)
    @classmethod
    def save_beam(cls, db: Session, payload): return cls._save_config(db, cls.BEAM_KEY, "Beam infrastructure provider", payload, "api_key")

    @classmethod
    def test_runpod(cls, db: Session) -> dict:
        cfg = cls.get_runpod(db)
        if not cfg.api_key:
            return {"success": False, "message": "Configura la API key de RunPod.", "details": {}}
        try:
            details = runpod_control_plane_service.account_probe(
                api_key=cfg.api_key,
                timeout_seconds=min(cfg.timeout_seconds, 60),
            )
            if cfg.endpoint_id:
                endpoint = runpod_control_plane_service.get_endpoint(
                    cfg.endpoint_id,
                    api_key=cfg.api_key,
                    timeout_seconds=min(cfg.timeout_seconds, 60),
                )
                details["endpoint"] = {
                    "id": endpoint.get("id"),
                    "name": endpoint.get("name"),
                    "workersMin": endpoint.get("workersMin"),
                    "workersMax": endpoint.get("workersMax"),
                }
            return {"success": True, "message": "Conexión con RunPod validada.", "details": details}
        except Exception as exc:
            return {"success": False, "message": "RunPod rechazó la configuración.", "details": {"error": str(exc)}}

    @classmethod
    def ensure_runpod_volume(cls, db: Session) -> dict:
        cfg = cls.get_runpod(db)
        if not cfg.api_key:
            return {"success": False, "message": "Configura la API key de RunPod.", "details": {}}

        timeout_seconds = min(cfg.timeout_seconds, 60)
        configured_id = str(cfg.network_volume_id or "").strip()
        stale_id_error: str | None = None

        try:
            # Un ID guardado puede quedar obsoleto, pertenecer a otra cuenta o haberse
            # copiado incorrectamente. Primero se intenta resolverlo, pero su fallo no
            # bloquea la búsqueda por nombre ni la creación del volumen.
            if configured_id:
                try:
                    volume = runpod_control_plane_service.get_network_volume(
                        configured_id,
                        api_key=cfg.api_key,
                        timeout_seconds=timeout_seconds,
                    )
                    return {
                        "success": True,
                        "message": "Network Volume de RunPod disponible.",
                        "details": volume,
                    }
                except Exception as exc:
                    stale_id_error = str(exc)
                    logger.warning(
                        "RunPod Network Volume ID no resoluble; se buscará por nombre: id=%s error=%s",
                        configured_id,
                        stale_id_error,
                    )

            volumes = runpod_control_plane_service.list_network_volumes(
                api_key=cfg.api_key,
                timeout_seconds=timeout_seconds,
            )
            wanted_name = str(cfg.network_volume_name or "").strip()
            wanted_dc = str(cfg.data_center_id or "").strip().upper()
            existing = next(
                (
                    item
                    for item in volumes
                    if str(item.get("name") or "").strip().casefold() == wanted_name.casefold()
                    and (
                        not wanted_dc
                        or str(item.get("dataCenterId") or "").strip().upper() == wanted_dc
                    )
                ),
                None,
            )
            if existing:
                cfg.network_volume_id = str(existing.get("id") or "").strip()
                cls.save_runpod(db, cfg)
                details = dict(existing)
                if stale_id_error:
                    details["replaced_stale_volume_id"] = configured_id
                    details["stale_volume_id_error"] = stale_id_error
                return {
                    "success": True,
                    "message": "Network Volume de RunPod encontrado y vinculado.",
                    "details": details,
                }

            if not wanted_name:
                return {
                    "success": False,
                    "message": "Configura el nombre del Network Volume.",
                    "details": {"stale_volume_id_error": stale_id_error},
                }
            if not wanted_dc:
                return {
                    "success": False,
                    "message": "Configura el Data Center ID para crear el Network Volume.",
                    "details": {
                        "volume_name": wanted_name,
                        "stale_volume_id_error": stale_id_error,
                    },
                }

            created = runpod_control_plane_service.create_network_volume(
                api_key=cfg.api_key,
                name=wanted_name,
                size_gb=cfg.network_volume_size_gb,
                data_center_id=wanted_dc,
                timeout_seconds=timeout_seconds,
            )
            created_id = str(created.get("id") or "").strip()
            if not created_id:
                raise RuntimeError(
                    f"RunPod creó el volumen pero no devolvió su ID: {created!r}"
                )
            cfg.network_volume_id = created_id
            cfg.data_center_id = wanted_dc
            cls.save_runpod(db, cfg)
            details = dict(created)
            if stale_id_error:
                details["replaced_stale_volume_id"] = configured_id
                details["stale_volume_id_error"] = stale_id_error
            return {
                "success": True,
                "message": "Network Volume de RunPod creado y vinculado.",
                "details": details,
            }
        except Exception as exc:
            logger.exception("No fue posible comprobar o crear el Network Volume de RunPod")
            return {
                "success": False,
                "message": (
                    "No fue posible comprobar o crear el Network Volume de RunPod. "
                    "Verifica que el Network Volume ID configurado exista y pertenezca a esta cuenta; "
                    "si ya no existe o no es correcto, elimina el ID y vuelve a intentarlo para crear o vincular un volumen nuevo."
                ),
                "details": {
                    "error": str(exc),
                    "configured_volume_id": configured_id or None,
                    "volume_name": str(cfg.network_volume_name or "").strip() or None,
                    "data_center_id": str(cfg.data_center_id or "").strip() or None,
                    "stale_volume_id_error": stale_id_error,
                },
            }

    @staticmethod
    def _beam_output(completed) -> str:
        return ((completed.stdout or "") + "\n" + (completed.stderr or "")).strip()

    @classmethod
    def _prepare_beam_cli(cls, cfg, *, timeout_seconds: int = 900):
        from app.services.beam_cli_environment_service import beam_cli_environment_service
        import tempfile

        executable = beam_cli_environment_service.ensure(timeout_seconds=timeout_seconds)
        home = tempfile.mkdtemp(prefix="tryon-beam-")
        env = os.environ.copy()
        env["HOME"] = home
        env["USERPROFILE"] = home
        env["BEAM_TOKEN"] = str(cfg.api_key or "").strip()
        configured = subprocess.run(
            [executable, "configure", "default", "--token", env["BEAM_TOKEN"]],
            env=env,
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if configured.returncode != 0:
            output = cls._beam_output(configured)
            shutil.rmtree(home, ignore_errors=True)
            raise RuntimeError("Beam CLI no pudo guardar la configuración del Token. " + output[-3000:])
        return executable, env, home

    @classmethod
    def test_beam(cls, db: Session) -> dict:
        cfg = cls.get_beam(db)
        if not cfg.api_key:
            return {"success": False, "message": "Configura el Token de Beam.", "details": {}}
        try:
            executable, env, home = cls._prepare_beam_cli(cfg, timeout_seconds=900)
        except Exception as exc:
            return {
                "success": False,
                "message": "No fue posible preparar Beam CLI: " + str(exc)[-1200:],
                "details": {"error": str(exc), "requirements": "requirements-beam.txt"},
            }
        try:
            listed = subprocess.run(
                [executable, "volume", "list"],
                env=env,
                stdin=subprocess.DEVNULL,
                capture_output=True,
                text=True,
                timeout=120,
            )
            output = cls._beam_output(listed)
            if listed.returncode != 0:
                lowered = output.lower()
                auth_error = any(word in lowered for word in ("unauthorized", "forbidden", "invalid token", "authentication", "401", "403"))
                return {
                    "success": False,
                    "message": "Beam rechazó el Token." if auth_error else "Beam CLI respondió con un error al probar la conexión.",
                    "details": {"output": output[-3000:]},
                }
            return {"success": True, "message": "Conexión con Beam validada.", "details": {"primary_key": cfg.workspace, "output": output[-3000:]}}
        finally:
            shutil.rmtree(home, ignore_errors=True)

    @staticmethod
    def _beam_volume_names(output: str) -> set[str]:
        """Extrae nombres completos de ``beam volume list`` sin usar coincidencias parciales."""
        ansi_re = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
        separator_re = re.compile(r"^[\s─━═\-]+$")
        names: set[str] = set()
        for line in ansi_re.sub("", output or "").splitlines():
            raw = line.strip()
            if not raw or separator_re.fullmatch(raw):
                continue
            lower = raw.casefold()
            if lower.startswith(("name ", "=>", "welcome ", "token:")):
                continue
            if re.match(r"^\d+\s+(?:item|items|volume|volumes)\b", lower):
                continue
            columns = [part.strip() for part in re.split(r"\s{2,}", raw) if part.strip()]
            if not columns:
                continue
            candidate = columns[0].rstrip("/")
            if candidate and candidate.casefold() not in {"name", "volume", "volumes"}:
                names.add(candidate)
        return names

    @classmethod
    def ensure_beam_volume(cls, db: Session) -> dict:
        cfg = cls.get_beam(db)
        volume_name = str(cfg.volume_name or "").strip()
        if not cfg.api_key:
            return {"success": False, "message": "Configura el Token de Beam.", "details": {}}
        if not volume_name:
            return {"success": False, "message": "Configura el nombre del volumen Beam.", "details": {}}
        try:
            executable, env, home = cls._prepare_beam_cli(cfg, timeout_seconds=900)
        except Exception as exc:
            return {
                "success": False,
                "message": "No fue posible preparar Beam CLI: " + str(exc)[-1200:],
                "details": {"error": str(exc), "requirements": "requirements-beam.txt"},
            }
        try:
            def list_current_volumes():
                completed = subprocess.run(
                    [executable, "volume", "list"],
                    env=env,
                    stdin=subprocess.DEVNULL,
                    capture_output=True,
                    text=True,
                    errors="replace",
                    timeout=120,
                )
                return completed, cls._beam_output(completed)

            listed, output = list_current_volumes()
            if listed.returncode != 0:
                return {
                    "success": False,
                    "message": "No fue posible consultar los volúmenes de Beam.",
                    "details": {"volume_name": volume_name, "output": output[-3000:]},
                }

            names = cls._beam_volume_names(output)
            if volume_name.casefold() in {name.casefold() for name in names}:
                return {
                    "success": True,
                    "message": "El volumen Beam ya existe.",
                    "details": {
                        "volume_name": volume_name,
                        "created": False,
                        "already_exists": True,
                        "output": output[-3000:],
                    },
                }

            created = subprocess.run(
                [executable, "volume", "create", volume_name],
                env=env,
                stdin=subprocess.DEVNULL,
                capture_output=True,
                text=True,
                errors="replace",
                timeout=180,
            )
            created_output = cls._beam_output(created)
            lowered = created_output.casefold()
            already_exists = any(
                marker in lowered
                for marker in ("already exists", "already_exist", "volume exists", "ya existe")
            )
            if created.returncode != 0 and not already_exists:
                return {
                    "success": False,
                    "message": "No fue posible crear el volumen Beam.",
                    "details": {"volume_name": volume_name, "output": created_output[-3000:]},
                }

            # Verificación final: evita afirmar que se creó un volumen que Beam no lista.
            verified, verified_output = list_current_volumes()
            verified_names = cls._beam_volume_names(verified_output) if verified.returncode == 0 else set()
            exists_after = volume_name.casefold() in {name.casefold() for name in verified_names}
            if not exists_after and not already_exists:
                return {
                    "success": False,
                    "message": "Beam respondió a la creación, pero el volumen no apareció al verificarlo.",
                    "details": {
                        "volume_name": volume_name,
                        "output": created_output[-3000:],
                        "verification_output": verified_output[-3000:],
                    },
                }

            if already_exists:
                message = "El volumen Beam ya existe."
                was_created = False
            else:
                message = "Volumen Beam creado correctamente."
                was_created = True
            return {
                "success": True,
                "message": message,
                "details": {
                    "volume_name": volume_name,
                    "created": was_created,
                    "already_exists": not was_created,
                    "output": created_output[-3000:],
                    "verification_output": verified_output[-3000:],
                },
            }
        finally:
            shutil.rmtree(home, ignore_errors=True)

    @staticmethod
    def _modal_env(config: ModalProviderConfig) -> dict[str, str]:
        env = os.environ.copy()
        env["MODAL_TOKEN_ID"] = config.token_id
        env["MODAL_TOKEN_SECRET"] = config.token_secret
        env["MODAL_ENVIRONMENT"] = config.environment
        return env

    @classmethod
    def test_modal(cls, db: Session) -> dict:
        config = cls.get_modal(db)
        if not config.token_id or not config.token_secret:
            return {"success": False, "message": "Configura Token ID y Token Secret antes de probar la conexión.", "details": {}}
        executable = shutil.which("modal")
        if not executable:
            return {"success": False, "message": "Modal CLI no está instalado en el backend. Instala el paquete modal para probar y administrar volúmenes.", "details": {"required_command": "pip install modal"}}
        completed = subprocess.run(
            [executable, "profile", "current"],
            env=cls._modal_env(config), capture_output=True, text=True, timeout=30,
        )
        output = (completed.stdout or completed.stderr or "").strip()
        return {
            "success": completed.returncode == 0,
            "message": "Conexión con Modal validada." if completed.returncode == 0 else "Modal rechazó la configuración.",
            "details": {"output": output[-2000:]},
        }

    @classmethod
    def ensure_volume(cls, db: Session) -> dict:
        config = cls.get_modal(db)
        if not config.token_id or not config.token_secret:
            return {"success": False, "message": "Configura las credenciales de Modal antes de crear el volumen.", "details": {}}
        executable = shutil.which("modal")
        if not executable:
            return {"success": False, "message": "Modal CLI no está instalado en el backend.", "details": {"required_command": "pip install modal"}}
        completed = subprocess.run(
            [executable, "volume", "create", config.volume_name],
            env=cls._modal_env(config), capture_output=True, text=True, timeout=60,
        )
        output = (completed.stdout or completed.stderr or "").strip()
        benign = "already exists" in output.lower()
        success = completed.returncode == 0 or benign
        return {
            "success": success,
            "message": "Volumen Modal disponible." if success else "No fue posible crear o comprobar el volumen Modal.",
            "details": {"volume_name": config.volume_name, "output": output[-3000:]},
        }


infrastructure_provider_service = InfrastructureProviderService()
