from __future__ import annotations

import json
import os
import queue
import re
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Any, Callable, TextIO

from app.services.beam_engine.beam_config import BeamSyncConfig

LineCallback = Callable[[str, dict[str, Any]], None]


class BeamMultipartClient:
    """Beam multipart uploader with byte-level progress.

    Beam's Rich progress bar is not a reliable machine-readable source when the
    CLI runs without an interactive terminal. Instead, the child Python process
    is instrumented through ``sitecustomize``. The instrumentation wraps the
    file-like object passed to ``requests.put`` and reports every ``read(size)``
    while Beam is uploading each multipart part.
    """

    ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
    PROGRESS_PREFIX = "__TRYON_BEAM_PROGRESS__="

    @classmethod
    def patch_windows_sdk(cls) -> list[str]:
        if os.name != "nt":
            return []
        patched: list[str] = []
        for base in map(Path, sys.path):
            if not base.exists():
                continue
            for path in base.glob("**/beam/**/multipart.py"):
                try:
                    text = path.read_text(encoding="utf-8")
                    updated = text.replace("os.path.join", "posixpath.join")
                    updated = updated.replace("os.path.basename", "posixpath.basename")
                    if "import posixpath" not in updated:
                        updated = "import posixpath\n" + updated
                    if updated != text:
                        path.write_text(updated, encoding="utf-8")
                        patched.append(str(path))
                except OSError:
                    continue
        return patched

    @staticmethod
    def _reader(stream: TextIO, output: queue.Queue[str]) -> None:
        try:
            buffer = ""
            while True:
                char = stream.read(1)
                if char == "":
                    if buffer.strip():
                        output.put(buffer)
                    return
                if char in {"\r", "\n"}:
                    if buffer.strip():
                        output.put(buffer)
                    buffer = ""
                else:
                    buffer += char
        finally:
            try:
                stream.close()
            except Exception:
                pass

    @classmethod
    def _sitecustomize_source(cls) -> str:
        # This module is loaded automatically by Python in the Beam CLI child.
        # It deliberately patches requests only; Beam SDK source remains intact.
        return r'''
from __future__ import annotations

import json
import os
import sys
import threading
import time

_PREFIX = "__TRYON_BEAM_PROGRESS__="
_TOTAL = max(1, int(os.environ.get("TRYON_BEAM_PROGRESS_TOTAL_BYTES", "1")))
_STARTED = time.perf_counter()
_SENT = 0
_LAST_EMIT = 0.0
_LOCK = threading.RLock()


def _emit(force=False):
    global _LAST_EMIT
    now = time.perf_counter()
    with _LOCK:
        if not force and now - _LAST_EMIT < 0.12:
            return
        sent = min(_TOTAL, max(0, _SENT))
        elapsed = max(0.001, now - _STARTED)
        speed = int(sent / elapsed)
        eta = int((_TOTAL - sent) / speed) if speed > 0 and sent < _TOTAL else 0
        payload = {
            "file_bytes_sent": sent,
            "file_progress": round(100.0 * sent / _TOTAL, 3),
            "speed_bps": speed,
            "eta_seconds": eta,
            "elapsed_seconds": round(elapsed, 3),
        }
        try:
            sys.stderr.write(_PREFIX + json.dumps(payload, separators=(",", ":")) + "\n")
            sys.stderr.flush()
        except Exception:
            pass
        _LAST_EMIT = now


class ProgressFile:
    def __init__(self, wrapped):
        self._wrapped = wrapped

    def read(self, size=-1):
        global _SENT
        chunk = self._wrapped.read(size)
        if chunk:
            try:
                amount = len(chunk)
            except Exception:
                amount = 0
            if amount:
                with _LOCK:
                    _SENT += amount
                _emit(False)
        else:
            _emit(True)
        return chunk

    def __getattr__(self, name):
        return getattr(self._wrapped, name)

    def __iter__(self):
        return self

    def __next__(self):
        chunk = self.read(1024 * 1024)
        if not chunk:
            raise StopIteration
        return chunk

    def __len__(self):
        try:
            return len(self._wrapped)
        except Exception:
            try:
                current = self._wrapped.tell()
                self._wrapped.seek(0, 2)
                end = self._wrapped.tell()
                self._wrapped.seek(current)
                return max(0, end - current)
            except Exception:
                raise TypeError


def _wrap_data(data):
    if data is None or isinstance(data, (bytes, bytearray, memoryview, str)):
        return data
    if isinstance(data, ProgressFile):
        return data
    if callable(getattr(data, "read", None)):
        return ProgressFile(data)
    return data


try:
    import requests.sessions

    _original_request = requests.sessions.Session.request

    def _progress_request(self, method, url, **kwargs):
        if str(method).upper() == "PUT" and "data" in kwargs:
            kwargs["data"] = _wrap_data(kwargs.get("data"))
        return _original_request(self, method, url, **kwargs)

    requests.sessions.Session.request = _progress_request
except Exception:
    pass
'''

    @classmethod
    def _metrics_from_line(cls, line: str) -> dict[str, Any] | None:
        clean = cls.ANSI.sub("", line).strip()
        if not clean.startswith(cls.PROGRESS_PREFIX):
            return None
        raw = clean[len(cls.PROGRESS_PREFIX) :]
        try:
            value = json.loads(raw)
        except (TypeError, ValueError, json.JSONDecodeError):
            return None
        return {
            "native_line": "Beam multipart: bytes leídos por requests.put",
            "file_progress": float(value.get("file_progress") or 0.0),
            "file_bytes_sent": int(value.get("file_bytes_sent") or 0),
            "speed_bps": int(value.get("speed_bps") or 0),
            "eta_seconds": int(value.get("eta_seconds") or 0),
            "elapsed_seconds": float(value.get("elapsed_seconds") or 0.0),
        }

    @classmethod
    def upload_file(
        cls,
        config: BeamSyncConfig,
        source: Path,
        destination: str,
        on_line: LineCallback,
    ) -> None:
        cls.patch_windows_sdk()
        source_size = source.stat().st_size
        normalized_destination = destination.replace("\\", "/")

        with tempfile.TemporaryDirectory(prefix="tryon-beam-progress-") as hook_dir:
            hook_path = Path(hook_dir) / "sitecustomize.py"
            hook_path.write_text(cls._sitecustomize_source(), encoding="utf-8")

            env = dict(config.env)
            current_pythonpath = env.get("PYTHONPATH", "")
            env["PYTHONPATH"] = hook_dir + (os.pathsep + current_pythonpath if current_pythonpath else "")
            env["TRYON_BEAM_PROGRESS_TOTAL_BYTES"] = str(source_size)
            env.setdefault("PYTHONUNBUFFERED", "1")

            process = subprocess.Popen(
                [config.executable, "cp", "--multipart", str(source), normalized_destination],
                env=env,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                errors="replace",
                bufsize=0,
            )
            started = time.perf_counter()
            output: queue.Queue[str] = queue.Queue()
            assert process.stdout is not None
            assert process.stderr is not None
            readers = [
                threading.Thread(target=cls._reader, args=(process.stdout, output), daemon=True),
                threading.Thread(target=cls._reader, args=(process.stderr, output), daemon=True),
            ]
            for reader in readers:
                reader.start()

            captured: list[str] = []
            last_metrics: dict[str, Any] = {
                "native_line": "Beam multipart preparando transferencia…",
                "file_progress": 0.0,
                "file_bytes_sent": 0,
                "speed_bps": 0,
                "eta_seconds": 0,
                "elapsed_seconds": 0.0,
            }
            last_emit = 0.0

            try:
                while process.poll() is None or any(reader.is_alive() for reader in readers) or not output.empty():
                    now = time.perf_counter()
                    if now - started > config.timeout_seconds:
                        process.kill()
                        raise TimeoutError(f"Beam multipart excedió {config.timeout_seconds} segundos.")
                    try:
                        line = output.get(timeout=0.2)
                    except queue.Empty:
                        if now - last_emit >= 1.0:
                            heartbeat = dict(last_metrics)
                            heartbeat["elapsed_seconds"] = round(now - started, 1)
                            on_line("Beam multipart activo…", heartbeat)
                            last_emit = now
                        continue

                    clean = cls.ANSI.sub("", line).strip()
                    if not clean:
                        continue
                    metrics = cls._metrics_from_line(clean)
                    if metrics is not None:
                        # Never allow a delayed/retried frame to move the UI backwards.
                        if metrics["file_bytes_sent"] >= int(last_metrics.get("file_bytes_sent") or 0):
                            last_metrics = metrics
                            on_line("Beam multipart enviando…", dict(last_metrics))
                            last_emit = time.perf_counter()
                        continue

                    captured.append(clean)
                    # Native Beam messages are useful in logs but must not reset metrics.
                    on_line(clean, dict(last_metrics))
                    last_emit = time.perf_counter()

                code = process.wait()
            except BaseException:
                if process.poll() is None:
                    process.terminate()
                raise

            if code != 0:
                detail = "\n".join(captured[-30:])
                raise RuntimeError(f"Beam multipart terminó con código {code}. {detail}".strip())

        elapsed = max(0.001, time.perf_counter() - started)
        on_line(
            "Transferencia multipart completada.",
            {
                "native_line": "Transferencia multipart completada.",
                "file_progress": 100.0,
                "file_bytes_sent": source_size,
                "speed_bps": int(source_size / elapsed),
                "eta_seconds": 0,
                "elapsed_seconds": round(elapsed, 3),
            },
        )
