"""Credenciales SSH locales para la exportación de modelos a RunPod.

ARCHIVO TEMPORAL Y LOCAL.
No debe subirse a Git. El .gitignore de esta misma carpeta lo excluye.

Reemplaza los dos valores de ejemplo con el contenido completo de tus archivos:
- C:\\Users\\frank\\.ssh\\tryon_runpod_export
- C:\\Users\\frank\\.ssh\\tryon_runpod_export.pub
"""

RUNPOD_SSH_PRIVATE_KEY_INLINE = """-----BEGIN OPENSSH PRIVATE KEY-----
PEGA_AQUI_LA_CLAVE_PRIVADA_COMPLETA
-----END OPENSSH PRIVATE KEY-----
"""

RUNPOD_SSH_PUBLIC_KEY_INLINE = """ssh-ed25519 PEGA_AQUI_LA_CLAVE_PUBLICA_COMPLETA tryon-runpod-export"""
