HOTFIX 01B - REGISTRO / TURNSTILE

1. Descomprime este ZIP directamente en la raíz de tryon_backend.
2. Ejecuta:

   powershell -ExecutionPolicy Bypass -File .\apply_hotfix.ps1

3. Verifica que el archivo contenga:

   user_dict.pop(
       "turnstile_token",
       None,
   )

4. Reinicia el backend.
