﻿$ErrorActionPreference = "Stop"

$target = Join-Path $PSScriptRoot "app\services\user_service.py"

if (-not (Test-Path $target)) {
    throw "No se encontró $target. Descomprime este ZIP en la raíz de tryon_backend."
}

$content = Get-Content -Raw -Encoding UTF8 $target

if ($content -match 'user_dict\.pop\(\s*"turnstile_token"') {
    Write-Host "El hotfix ya está aplicado." -ForegroundColor Yellow
    exit 0
}

$needle = @'
        age_confirmed = bool(
            user_dict.pop(
                "age_confirmed",
                False,
            )
        )

        user_dict["email"] = (
'@

$replacement = @'
        age_confirmed = bool(
            user_dict.pop(
                "age_confirmed",
                False,
            )
        )

        # Campo usado solo para validación anti-bot; no pertenece al modelo User.
        user_dict.pop(
            "turnstile_token",
            None,
        )

        user_dict["email"] = (
'@

if (-not $content.Contains($needle)) {
    throw "No se encontró el bloque esperado. No se modificó el archivo."
}

Copy-Item $target "$target.before_turnstile_hotfix" -Force
$content = $content.Replace($needle, $replacement)
Set-Content -Path $target -Value $content -Encoding UTF8

Write-Host "Hotfix aplicado correctamente en app\services\user_service.py" -ForegroundColor Green
Write-Host "Respaldo: app\services\user_service.py.before_turnstile_hotfix"
