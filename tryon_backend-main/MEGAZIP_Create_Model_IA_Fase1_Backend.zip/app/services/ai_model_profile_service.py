from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.ai_model_profile import AiModelProfile
from app.models.body_proportion_tool import BodyProportionPreset
from app.models.storage_file import StorageFile
from app.services.storage_service import storage_service


class AiModelProfileService:
    def _image_url(self, db: Session, preset: BodyProportionPreset | None) -> str | None:
        if not preset or not preset.image_storage_file_id:
            return None
        stored = db.get(StorageFile, preset.image_storage_file_id)
        return storage_service.create_presigned_url(db, storage_file=stored) if stored else None

    def catalog(self, db: Session, sex: str) -> list[dict]:
        if sex not in {"woman", "man"}:
            raise ValueError("Invalid sex.")
        rows = list(db.execute(select(BodyProportionPreset).where(
            BodyProportionPreset.sex == sex,
            BodyProportionPreset.status == "ready",
            BodyProportionPreset.image_storage_file_id.is_not(None),
        ).order_by(BodyProportionPreset.sort_order.asc(), BodyProportionPreset.id.asc())).scalars().all())
        result = []
        for row in rows:
            image_url = self._image_url(db, row)
            if not image_url:
                continue
            result.append({
                "id": row.id, "display_name": row.display_name, "sex": row.sex,
                "hips_size": row.hips_size, "fat_thin": row.fat_thin, "breasts_size": row.breasts_size,
                "skin_tone": row.skin_tone, "hair_length": row.hair_length,
                "fat_band": row.fat_band, "hips_band": row.ass_band, "breast_band": row.breast_band,
                "image_url": image_url, "sort_order": row.sort_order,
            })
        return result

    def list_models(self, db: Session, user_id: int) -> list[AiModelProfile]:
        return list(db.execute(select(AiModelProfile).where(AiModelProfile.user_id == user_id).order_by(AiModelProfile.updated_at.desc())).scalars().all())

    def get(self, db: Session, user_id: int, model_id: int) -> AiModelProfile:
        row = db.execute(select(AiModelProfile).where(AiModelProfile.id == model_id, AiModelProfile.user_id == user_id)).scalar_one_or_none()
        if not row:
            raise LookupError("AI model not found.")
        return row

    def create(self, db: Session, user_id: int, name: str, sex: str) -> AiModelProfile:
        if sex == "man":
            raise ValueError("Male model creation is prepared but not enabled yet.")
        row = AiModelProfile(user_id=user_id, name=name.strip(), sex=sex, stage="body")
        db.add(row); db.commit(); db.refresh(row); return row

    def set_body(self, db: Session, user_id: int, model_id: int, preset_id: int) -> AiModelProfile:
        row = self.get(db, user_id, model_id)
        preset = db.get(BodyProportionPreset, preset_id)
        if not preset or preset.sex != row.sex or preset.status != "ready" or not preset.image_storage_file_id:
            raise ValueError("The selected body variant is not available.")
        row.body_proportion_preset_id = preset.id
        row.stage = "body_selected"
        db.add(row); db.commit(); db.refresh(row); return row

    def response(self, db: Session, row: AiModelProfile) -> dict:
        preset = db.get(BodyProportionPreset, row.body_proportion_preset_id) if row.body_proportion_preset_id else None
        return {
            "id": row.id, "name": row.name, "sex": row.sex,
            "body_proportion_preset_id": row.body_proportion_preset_id,
            "body_image_url": self._image_url(db, preset), "stage": row.stage,
            "created_at": row.created_at, "updated_at": row.updated_at,
        }

ai_model_profile_service = AiModelProfileService()
