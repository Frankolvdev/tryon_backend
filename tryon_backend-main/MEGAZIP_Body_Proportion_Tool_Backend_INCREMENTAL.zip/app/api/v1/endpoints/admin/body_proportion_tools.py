from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy.orm import Session

from app.api.v1.deps import get_db
from app.api.v1.guards.admin_guard import admin_guard
from app.models.user import User
from app.schemas.body_proportion_tool import (
    BodyProportionGenerationResponse,
    BodyProportionHealthResponse,
    BodyProportionInterpolateRequest,
    BodyProportionNextRequest,
    BodyProportionPresetCreate,
    BodyProportionPresetListResponse,
    BodyProportionPresetResponse,
    BodyProportionPresetUpdate,
    BodyProportionWorkflowConfigResponse,
    BodyProportionWorkflowConfigUpsert,
)
from app.services.body_proportion_tool_service import body_proportion_tool_service
from app.services.comfyui_local_adapter_service import comfyui_local_adapter_service

router = APIRouter(prefix="/tools-generation/body-proportions")


def _bad_request(error: Exception):
    if isinstance(error, LookupError):
        raise HTTPException(status_code=404, detail=str(error)) from error
    raise HTTPException(status_code=400, detail=str(error)) from error


@router.get("/health", response_model=BodyProportionHealthResponse)
def health(current_admin: User = Depends(admin_guard)):
    return {"local_only": True, "comfyui": comfyui_local_adapter_service.health()}


@router.get("/config/{sex}", response_model=BodyProportionWorkflowConfigResponse)
def get_config(sex: str, db: Session = Depends(get_db), current_admin: User = Depends(admin_guard)):
    try:
        return body_proportion_tool_service.get_config(db, sex)
    except Exception as error:
        _bad_request(error)


@router.put("/config/{sex}", response_model=BodyProportionWorkflowConfigResponse)
def put_config(data: BodyProportionWorkflowConfigUpsert, sex: str, db: Session = Depends(get_db), current_admin: User = Depends(admin_guard)):
    try:
        return body_proportion_tool_service.upsert_config(db, sex, data)
    except Exception as error:
        _bad_request(error)


@router.get("/presets", response_model=BodyProportionPresetListResponse)
def list_presets(sex: str = "woman", db: Session = Depends(get_db), current_admin: User = Depends(admin_guard)):
    try:
        rows = body_proportion_tool_service.list_presets(db, sex)
        return {"items": [body_proportion_tool_service.response(db, row) for row in rows], "total": len(rows)}
    except Exception as error:
        _bad_request(error)


@router.post("/presets", response_model=BodyProportionPresetResponse, status_code=status.HTTP_201_CREATED)
def create_preset(data: BodyProportionPresetCreate, db: Session = Depends(get_db), current_admin: User = Depends(admin_guard)):
    try:
        row = body_proportion_tool_service.create_preset(db, data)
        return body_proportion_tool_service.response(db, row)
    except Exception as error:
        _bad_request(error)


@router.post("/presets/{preset_id}/next", response_model=BodyProportionPresetResponse, status_code=status.HTTP_201_CREATED)
def create_next(preset_id: int, data: BodyProportionNextRequest, db: Session = Depends(get_db), current_admin: User = Depends(admin_guard)):
    try:
        row = body_proportion_tool_service.create_next(db, preset_id, data.display_name)
        return body_proportion_tool_service.response(db, row)
    except Exception as error:
        _bad_request(error)


@router.post("/presets/interpolate", response_model=BodyProportionPresetResponse, status_code=status.HTTP_201_CREATED)
def interpolate(data: BodyProportionInterpolateRequest, db: Session = Depends(get_db), current_admin: User = Depends(admin_guard)):
    try:
        row = body_proportion_tool_service.interpolate(db, data)
        return body_proportion_tool_service.response(db, row)
    except Exception as error:
        _bad_request(error)


@router.patch("/presets/{preset_id}", response_model=BodyProportionPresetResponse)
def update_preset(preset_id: int, data: BodyProportionPresetUpdate, db: Session = Depends(get_db), current_admin: User = Depends(admin_guard)):
    try:
        row = body_proportion_tool_service.update_preset(db, preset_id, data)
        return body_proportion_tool_service.response(db, row)
    except Exception as error:
        _bad_request(error)


@router.delete("/presets/{preset_id}")
def delete_preset(preset_id: int, db: Session = Depends(get_db), current_admin: User = Depends(admin_guard)):
    try:
        body_proportion_tool_service.delete_preset(db, preset_id)
        return {"deleted": True, "preset_id": preset_id}
    except Exception as error:
        _bad_request(error)


@router.post("/presets/{preset_id}/generate", response_model=BodyProportionGenerationResponse)
def generate_preset(preset_id: int, db: Session = Depends(get_db), current_admin: User = Depends(admin_guard)):
    try:
        row, prompt_id, provider, overwritten = body_proportion_tool_service.generate(db, preset_id)
        return {
            "preset": body_proportion_tool_service.response(db, row),
            "prompt_id": prompt_id,
            "storage_provider": provider,
            "overwritten": overwritten,
        }
    except Exception as error:
        _bad_request(error)
